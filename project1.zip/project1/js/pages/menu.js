export function menuYeet(pageName) {
    // $('body').last().addClass('_breatheBg');
    // $('#intro').last().addClass('_breathe');
    console.log($(document));
}